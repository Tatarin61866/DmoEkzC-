﻿using OOO_sport_product.Classes;
using OOO_sport_product.Model;
using OOO_sport_product.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OOO_sport_product
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Classes.Helper.DBHall = new Model.DBHall();
        }

        private void buttonNavigate_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void buttonInput_Click(object sender, RoutedEventArgs e)
        {

        }

        private void buttonInput_Click_1(object sender, RoutedEventArgs e)
        {
            String check_login = textBoxLogin.Text;
            String check_password = textBlockPassword.Text;

            StringBuilder sb = new StringBuilder();

            if (String.IsNullOrEmpty(check_login) || String.IsNullOrEmpty(check_password))
            {
                sb.AppendLine("Неверный логин или пароль");
            }
            if (sb.Length > 0)
            {
                MessageBox.Show(sb.ToString());
            }
            //получение всех пользователей
            List<Model.User> users = new List<Model.User>();
            users = Helper.DBHall.User.ToList();

            MessageBox.Show("Число пользователей: " + users.Count);

            Model.User user = Helper.DBHall.User.Where(u => u.UserLogin == check_login && u.UserPassword == check_password).FirstOrDefault();
            if (user != null)
            {
                MessageBox.Show(user.UserFirstName + " " +user.UserLastName);

                goCatalog();
            }
            else
            {
                MessageBox.Show("Нет пользователей");
            }
        }

        private void buttonGuest_Click(object sender, RoutedEventArgs e)
        {
            goCatalog();
           
        }

        private void textBoxLogin_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        public void goCatalog() 
        {
            Catalog catalog = new Catalog();
            this.Hide();
            catalog.ShowDialog();
            this.Show();
        }
    }
}
