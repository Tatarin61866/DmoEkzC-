﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOO_sport_product.Classes
{
    internal class Helper
    {
        public static Model.DBHall DBHall { get; set; }
    }
}
